const CACHE_NAME = 'atlas3d-v2';
const CORE_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
];
const ICON_ASSETS = [
  '/iconos/icon-192.png',
  '/iconos/icon-512.png',
  '/iconos/icon-512-maskable.png',
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(async cache => {
      await cache.addAll(CORE_ASSETS);
      for (const url of ICON_ASSETS) {
        const respuesta = await fetch(url);
        await cache.put(url, respuesta);
      }
    })
  );
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(nombres =>
      Promise.all(
        nombres.filter(nombre => nombre !== CACHE_NAME).map(nombre => caches.delete(nombre))
      )
    ).then(() => self.clients.claim())
  );
});

function cacheFirst(peticion) {
  return caches.match(peticion).then(enCache => {
    if (enCache) return enCache;
    return fetch(peticion).then(respuesta => {
      const clon = respuesta.clone();
      caches.open(CACHE_NAME).then(cache => cache.put(peticion, clon));
      return respuesta;
    });
  });
}

function networkFirst(peticion) {
  return fetch(peticion)
    .then(respuesta => {
      const clon = respuesta.clone();
      caches.open(CACHE_NAME).then(cache => cache.put(peticion, clon));
      return respuesta;
    })
    .catch(() => caches.match(peticion));
}

function staleWhileRevalidate(peticion) {
  return caches.open(CACHE_NAME).then(cache =>
    cache.match(peticion).then(enCache => {
      const actualizacion = fetch(peticion).then(respuesta => {
        cache.put(peticion, respuesta.clone());
        return respuesta;
      });
      return enCache || actualizacion;
    })
  );
}

// Enrutado por tipo de recurso (Sesión 32, espejo de la Sesión 21).
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);

  if (url.pathname.startsWith('/iconos/')) {
    event.respondWith(cacheFirst(event.request));
  } else if (url.pathname.startsWith('/api/')) {
    event.respondWith(networkFirst(event.request));
  } else {
    event.respondWith(staleWhileRevalidate(event.request));
  }
});
